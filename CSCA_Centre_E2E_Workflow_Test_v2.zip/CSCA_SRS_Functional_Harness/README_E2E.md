# CSCA Centre — Controlled E2E Write Test

Based on the supplied **CSCA Case API** (`/libraries/v1/workflow-openapi.json`) and the CSCA-SRS-001 requirements. This script is **separate** from the read-only `csca_srs_test.py` runner. It is intended to test **synthetic or explicitly authorized test cases**, not live customer assessments.

## What it can do

1. **Create a simulated case** with `POST /cases/simulate`. This endpoint creates a unique mock RITM, *does not call ServiceNow*, and is only available when `SIMULATE_REQUEST_ENABLED=true` in the target environment. The documented default is disabled; expect HTTP 503 if it has not been enabled.
2. **Triage and initiate interview** using two `PATCH /cases/{ritm}` calls; the API may reject transitions if required data or authorizations are missing. The harness records the server error and **stops**.
3. **Read the generated interview questions** from `GET /cases/{ritm}`; collect explicit answers and submit `POST /cases/{ritm}/interview`. Verify `scoping_in_progress` and stored answers.
4. **Submit reviewed assets** from `case.diagram.asset_profiles` (or explicit `--assets` JSON) with `POST /cases/{ritm}/assets`. Re-read case for persistence.
5. **Inspect assigned controls**, and optionally submit the *unchanged control set* via `PATCH /cases/{ritm}/controls` with `--test-controls` to verify PATCH/persistence. This is **not** proof of correct control-scoping logic; use the read-only SRS baseline evaluator for that.
6. **Read the generated questionnaire**, collect explicit responses and submit `POST /cases/{ritm}/questionnaire`. Verify `gap_analysis` and saved responses.
7. **Read GAP analysis state** and **stop before validation**. There is no documented validation write endpoint in the supplied helpers.

The script **never generates arbitrary answers**, **never uploads evidence automatically**, and **never calls an undocumented endpoint**. If a response needs evidence, prepare its allowed artifact reference(s) separately. HTTP 409/422 conflicts are reported instead of bypassed.

## Installation and environment

```powershell
python -m pip install -r requirements.txt
$env:CSCA_BASE_URL = "https://YOUR-HOST/libraries/v1"
$env:CSCA_LIBRARY_KEY = "YOUR-API-KEY" # Or use --bearer + CSCA_BEARER_TOKEN
```

Do not put credentials in JSON templates or check them into source control. The script does not write authentication headers or credentials to its reports.

## Run on a new simulated assessment

```powershell
python .\csca_e2e_test.py --simulate --allow-write --team "Cloud" --interactive --verbose
```

If your authorized TEST system has an untrusted certificate and you have not installed its corporate CA bundle, the runner accepts **`--insecure`** as a temporary diagnostic option, as in your previous harness. That option disables HTTPS server identity verification and is unsafe for production credentials. Prefer `--ca-bundle "C:\Certs\corporate.pem"` once available.

```powershell
python .\csca_e2e_test.py --simulate --allow-write --team "Cloud" --interactive --insecure
```

The `--interactive` option prints each returned question and asks for an explicit answer. `yes`, `no`, `true`, and `false` are converted to booleans; numeric selections map to returned option values. Blank answers pause the run without submitting an incomplete batch.

## Let the harness pause, then supply answers

If you omit `--interactive`, the script stops at the first unanswered stage and writes:

- `e2e_reports/CSCA_E2E_<RITM>_interview_questions.json` or `..._questionnaire_questions.json`: full questions from that API response.
- `e2e_reports/CSCA_E2E_<RITM>_answers_template.json`: a map of question ID / asset ID to **null** placeholders.
- `e2e_reports/CSCA_E2E_<RITM>_checkpoint.json`: RITM and completed stage markers for resumption.

Example synthetic answers file (populate based on *the current test case*, not on a generic example):

```json
{
  "interview": {
    "PQ-001": true,
    "IT-AC-07": false
  },
  "questionnaire": {
    "app-service|IT-AC-02-a": true,
    "app-service|IT-AC-02-b": {
      "response": "Yes",
      "artifacts": [{"key": "previously-uploaded-evidence-reference"}]
    }
  }
}
```

The first `|`-separated component is the **asset_id** (empty if unscoped), and the second is the **question_id**. For each question, use the actual returned `question_id`, `asset_id`, `options`, expected response type, and evidence conditions. The example above is **illustrative** and is not a valid substitute for actual returned questions or uploaded evidence. Never invent artifact IDs; use references returned by the API's evidence upload operation.

Resume:

```powershell
python .\csca_e2e_test.py --resume .\e2e_reports\CSCA_E2E_RITM1234567-MOCK_checkpoint.json `
    --allow-write --answers .\e2e_reports\CSCA_E2E_RITM1234567-MOCK_answers_template.json --insecure
```

A checkpoint avoids re-submitting already successfully tested asset/control operations. On resumption the runner *re-reads* the current case, so actual state takes precedence over the checkpoint; do not edit a mock case externally between runs.

## Existing test RITM (only with explicit authorization)

If simulation is disabled, you may target an **authorized disposable test case**, not a production/customer case. To guard against accidental writes, the RITM must be repeated exactly:

```powershell
python .\csca_e2e_test.py --ritm RITM1234567 --confirm-ritm RITM1234567 `
    --allow-write --team "Cloud" --interactive
```

This modifies the specified record; it does not create a new one. **Do not use a real production RITM.** The script does not roll back writes.

## Evidence and artifacts

Every run saves timestamped `.txt` and `.json` reports and a checkpoint under `e2e_reports/`. The report includes requirement IDs, PASS/FAIL/BLOCKED/SKIP, REST operation, HTTP code, time, and the last confirmed workflow state. Raw API response bodies are not retained by default; HTTP error details can appear in reports. Treat all outputs, especially the questions JSON, as internal assessment data.

For question types requiring evidence, the Case API documents `POST /cases/{ritm}/evidence` (multipart) and attaching returned references to `POST /cases/{ritm}/questionnaire`. Automated evidence uploading and judgment about evidence quality are **not implemented** in this E2E script.

## Known boundaries

- **No validation execution:** absent from the supplied Case API operations; the runner stops at `gap_analysis`.
- **No automatic LIR acceptance:** accepted LIR closes the case and bypasses standard-path testing. Use a case eligible for the full assessment path; manual LIR decisions are outside this runner.
- **No ServiceNow import:** only simulated-case creation or specifically authorized existing test cases.
- **No imaginary questions/answers:** question contents are retrieved from the live response. To receive help selecting synthetic test responses, share the **sanitized** question JSON here, and the matching `--answers` data can be prepared.
- **No end-to-end proof of SRS compliance:** use independent workbook/reference baselines to verify tier, controls, questionnaire, and GAP calculations; this runner verifies progression and data persistence.
- `--insecure` does not fix certificate trust and should only be used temporarily in an isolated, authorized test setting.

## Offline tests

```powershell
python -m unittest -v test_csca_e2e.py
python -m unittest -v test_csca_srs.py
```

These tests use an in-memory fake API. They do **not** make network calls, and do not establish that the real CSCA Centre API is functioning.
