"""CSCA Centre controlled end-to-end workflow test.

Uses the documented Case API. Intended for an approved test environment and
simulated cases. All writes require --allow-write; no credentials are logged.
No business responses are guessed: use --interactive or --answers.
"""

import argparse
import json
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote

import requests


STATUSES = ("triage", "ready_to_work", "intake_interview", "scoping_in_progress",
            "gap_response_pending", "gap_analysis", "complete")


def timestamp():
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%SZ")


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def shorten(value, length=220):
    text = str(value).replace("\n", " ").replace("\r", " ")
    return text if len(text) <= length else text[:length - 3] + "..."


def read_json(path):
    with open(path, encoding="utf-8-sig") as stream:
        return json.load(stream)


def save_json(path, obj):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


class CaseApi:
    def __init__(self, base_url, key, bearer=False, insecure=False, ca_bundle=None, timeout=30,
                 session=None):
        self.base_url = base_url.rstrip("/")
        self.session = session if session is not None else requests.Session()
        self.session.headers.update({"Accept": "application/json"})
        if bearer:
            self.session.headers["Authorization"] = "Bearer " + key
        else:
            self.session.headers["X-CSCA-Library-Key"] = key
        self.verify = False if insecure else (ca_bundle or True)
        self.timeout = timeout

    def call(self, method, path, payload=None):
        start = time.monotonic()
        try:
            response = self.session.request(method, self.base_url + path, json=payload,
                                            timeout=self.timeout, verify=self.verify)
        except requests.RequestException as error:
            return None, None, type(error).__name__ + ": " + shorten(error), 0.0
        elapsed = round((time.monotonic() - start) * 1000, 1)
        try:
            data = response.json()
        except ValueError:
            data = {"message": shorten(response.text)}
        return response.status_code, data, "", elapsed


def answer_for(question, supplied, group):
    question_id = str(question.get("question_id") or "")
    asset_id = str(question.get("asset_id") or "")
    answers = supplied.get(group, {})
    compound = asset_id + "|" + question_id
    if isinstance(answers, dict) and compound in answers:
        return True, answers[compound]
    if isinstance(answers, dict) and question_id in answers:
        return True, answers[question_id]
    return False, None


def parse_interactive(raw, question):
    raw = raw.strip()
    if raw.lower() in ("y", "yes", "true"):
        return True
    if raw.lower() in ("n", "no", "false"):
        return False
    options = question.get("options") or question.get("response_options") or []
    if options and raw.isdigit() and 1 <= int(raw) <= len(options):
        return options[int(raw) - 1]
    return raw


def gather_answers(questions, supplied, group, interactive=False):
    """Return (answered, missing). Never synthesize assertions about a real case."""
    answered = {}
    missing = []
    for q in questions:
        if not isinstance(q, dict):
            continue
        qid = q.get("question_id")
        if not qid:
            continue
        asset = str(q.get("asset_id") or "")
        key = asset + "|" + str(qid) if group == "questionnaire" else str(qid)
        found, value = answer_for(q, supplied, group)
        if (not found or value is None or value == "") and interactive:
            print("\n" + group.upper() + ": " + key)
            print("  " + str(q.get("question") or q.get("attestation_question") or q.get("question_text") or "Question not described"))
            options = q.get("options") or q.get("response_options") or []
            if options:
                for i, option in enumerate(options, 1):
                    print(f"   {i}. {option}")
            if q.get("artifact_required"):
                print("  Evidence requirement: " + str(q["artifact_required"]))
            raw = input("  Answer [yes/no, option, text; Enter to pause]: ")
            if raw.strip():
                found, value = True, parse_interactive(raw, q)
        if not found or value is None or value == "":
            missing.append(key)
            continue
        answered[key] = value
    return answered, missing


def questionnaire_payload(questions, answers):
    records = []
    for q in questions:
        qid = str(q.get("question_id") or "")
        if not qid:
            continue
        asset_id = str(q.get("asset_id") or "")
        key = asset_id + "|" + qid
        if key not in answers:
            continue
        raw = answers[key]
        record = {"question_id": qid, "asset_id": asset_id}
        if isinstance(raw, dict):
            # Additional documented response fields are explicit test inputs.
            record["response"] = raw.get("response")
            if "artifacts" in raw:
                record["artifacts"] = raw["artifacts"]
            if "inherited_from" in raw:
                record["inherited_from"] = raw["inherited_from"]
        else:
            record["response"] = raw
        records.append(record)
    return {"responses": records}


class E2ERunner:
    def __init__(self, api, directory, interactive=False, supplied=None, team=None,
                 asset_profiles=None, test_controls=False, verbose=False,
                 completed_actions=None):
        self.api = api
        self.dir = Path(directory)
        self.dir.mkdir(parents=True, exist_ok=True)
        self.interactive = interactive
        self.supplied = supplied if supplied is not None else {}
        self.team = team
        self.asset_profiles = asset_profiles
        self.test_controls = test_controls
        self.verbose = verbose
        self.steps = []
        self.calls = []
        self.ritm = None
        self.simulated = False
        self.reason = ""
        self.case = None
        self.started = utc_now()
        self.completed_actions = list(completed_actions or [])

    def step(self, requirement, title, result, detail=""):
        record = {"requirement": requirement, "step": title, "result": result, "detail": detail}
        self.steps.append(record)
        print(f"{requirement:<12} {result:<8} {title}")
        if self.verbose and detail:
            print(" " * 21 + shorten(detail, 420))
        return result == "PASS"

    def call(self, method, path, payload=None, successful=(200,)):
        status, data, error, duration = self.api.call(method, path, payload)
        self.calls.append({"at": utc_now(), "method": method, "path": path,
                           "http_status": status, "duration_ms": duration,
                           "error": shorten(error) if error else ""})
        print(f"  {method:<5} {path} -> {status if status is not None else 'ERROR'}")
        if status not in successful:
            details = "Network: " + error if error else "HTTP " + str(status) + ": " + shorten(data)
            self.reason = details
            print("  " + details)
            return None
        if not isinstance(data, dict):
            self.reason = "Expected a JSON object, received a different response"
            return None
        return data

    def path(self, suffix=""):
        return "/cases/" + quote(str(self.ritm), safe="") + suffix

    def state_file(self):
        return self.dir / ("CSCA_E2E_" + str(self.ritm) + "_checkpoint.json")

    def checkpoint(self):
        if not self.ritm:
            return
        save_json(self.state_file(), {"ritm": self.ritm, "simulated": self.simulated,
                                     "last_seen_status": (self.case or {}).get("status"),
                                     "updated_at_utc": utc_now(),
                                     "completed_actions": self.completed_actions})

    def report(self):
        stamp = timestamp()
        prefix = "CSCA_E2E_" + (self.ritm or "START") + "_" + stamp
        data = {"started_at_utc": self.started, "finished_at_utc": utc_now(),
                "ritm": self.ritm, "simulated": self.simulated,
                "last_seen_status": (self.case or {}).get("status"),
                "stopped_reason": self.reason,
                "steps": self.steps, "api_calls": self.calls,
                "checkpoint": str(self.state_file()) if self.ritm else None,
                "note": "Individual checks are not proof of complete SRS compliance."}
        save_json(self.dir / (prefix + ".json"), data)
        lines = ["CSCA CENTRE — END-TO-END WORKFLOW TEST", "=" * 80,
                 "Started (UTC): " + self.started, "RITM: " + str(self.ritm),
                 "Simulated: " + str(self.simulated),
                 "Last observed status: " + str(data["last_seen_status"]), "",
                 f"{'REQUIREMENT':<13} {'RESULT':<9} TEST", "-" * 80]
        for row in self.steps:
            lines.append(f"{row['requirement']:<13} {row['result']:<9} {row['step']}")
            if row["detail"]:
                lines.append(" " * 23 + row["detail"])
        lines += ["", "STOP REASON: " + (self.reason or "Reached planned workflow boundary"),
                  "", "API CALLS", "-" * 80]
        for call in self.calls:
            lines.append("{method:<6} {path:<50} {http_status}".format(**call))
        path = self.dir / (prefix + ".txt")
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        self.checkpoint()
        print("\nReport: " + str(path))
        if self.ritm:
            print("Checkpoint: " + str(self.state_file()))
        return data

    def get_case(self):
        case = self.call("GET", self.path())
        if case is None:
            self.step("ASSESS-001", "Retrieve case", "FAIL", self.reason)
            return False
        if case.get("ritm") != self.ritm:
            self.reason = "RITM mismatch in case GET response"
            self.step("ASSESS-001", "Verify RITM identity", "FAIL", self.reason)
            return False
        self.case = case
        self.step("ASSESS-001", "Retrieve case and verify RITM", "PASS", case.get("status", ""))
        self.checkpoint()
        return True

    def write_and_verify(self, requirement, label, method, suffix, payload, expected_status=None,
                         expected_field=None, expected_value=None, action_key=None):
        response = self.call(method, self.path(suffix), payload)
        if response is None:
            self.step(requirement, label, "BLOCKED", self.reason)
            return False
        if not self.get_case():
            self.step(requirement, label, "FAIL", "Could not verify persisted data after write")
            return False
        if expected_status and self.case.get("status") != expected_status:
            self.reason = ("Expected state " + expected_status + ", observed " +
                           str(self.case.get("status")))
            self.step(requirement, label, "FAIL", self.reason)
            return False
        if expected_field:
            observed = self.case.get(expected_field)
            if observed != expected_value:
                self.reason = "Persisted " + expected_field + " differs from submitted value"
                self.step(requirement, label, "FAIL", self.reason)
                return False
        self.step(requirement, label, "PASS", "Write succeeded; persisted state confirmed by GET")
        if action_key and action_key not in self.completed_actions:
            self.completed_actions.append(action_key)
            self.checkpoint()
        return True

    def create_simulated(self):
        response = self.call("POST", "/cases/simulate", successful=(201,))
        if response is None:
            self.step("ASSESS-001", "Create simulated assessment", "BLOCKED", self.reason)
            return False
        self.ritm = response.get("ritm")
        self.simulated = True
        if not self.ritm:
            self.reason = "Simulation returned no RITM"
            self.step("ASSESS-001", "Create simulated assessment", "FAIL", self.reason)
            return False
        self.step("ASSESS-001", "Create simulated assessment", "PASS", "New RITM: " + self.ritm)
        print("SIMULATED RITM: " + self.ritm)
        return True

    def pause_answers(self, name, questions, group, missing):
        template = self.dir / ("CSCA_E2E_" + str(self.ritm) + "_answers_template.json")
        value = {"interview": {}, "questionnaire": {}}
        if template.exists():
            try:
                value = read_json(template)
            except (OSError, ValueError):
                pass
        for q in questions:
            if not isinstance(q, dict) or not q.get("question_id"):
                continue
            key = (str(q.get("asset_id") or "") + "|" if group == "questionnaire" else "") + str(q["question_id"])
            if key not in value.get(group, {}):
                value.setdefault(group, {})[key] = None
        save_json(template, value)
        question_file = self.dir / ("CSCA_E2E_" + str(self.ritm) + "_" + group + "_questions.json")
        save_json(question_file, {"ritm": self.ritm, "stage": group, "questions": questions})
        print("  Questions: " + str(question_file))
        self.reason = name + ": missing answers " + ", ".join(missing[:12])
        if len(missing) > 12:
            self.reason += f" ... ({len(missing)} total)"
        self.step("QUEST-001" if group == "questionnaire" else "ASSESS-003",
                  "Collect " + group + " answers", "BLOCKED", self.reason)
        print("  Fill answers in: " + str(template))
        print("  Provide --answers FILE and --resume CHECKPOINT, or use --interactive.")

    def advance_intake(self):
        state = self.case.get("status")
        if state == "triage":
            team = self.team or self.case.get("service_team")
            if not team:
                self.reason = "Triage needs a service team; rerun with --team NAME"
                self.step("INTAKE-006", "Triage assignment", "BLOCKED", self.reason)
                return False
            if not self.write_and_verify("ASSESS-003", "Complete triage", "PATCH", "",
                                         {"service_team": team, "status": "ready_to_work"},
                                         expected_status="ready_to_work"):
                return False
            state = self.case.get("status")
        if state == "ready_to_work":
            if not self.write_and_verify("ASSESS-003", "Begin intake interview", "PATCH", "",
                                         {"status": "intake_interview"},
                                         expected_status="intake_interview"):
                return False
        return True

    def submit_interview(self):
        if self.case.get("status") != "intake_interview":
            return True
        interview = self.case.get("interview") or {}
        questions = interview.get("questions") or []
        if not isinstance(questions, list) or not questions:
            self.reason = "No interview questions exposed for this case in current state"
            self.step("ASSESS-003", "Load interview questions", "BLOCKED", self.reason)
            return False
        answers, missing = gather_answers(questions, self.supplied, "interview", self.interactive)
        if missing:
            self.pause_answers("Interview", questions, "interview", missing)
            return False
        simple = {qid: answer for qid, answer in answers.items()}
        if not self.write_and_verify("CTRL-003", "Submit interview and recalculate scope",
                                     "POST", "/interview", {"answers": simple},
                                     expected_status="scoping_in_progress"):
            return False
        saved = (self.case.get("interview") or {}).get("submitted_answers") or {}
        if not isinstance(saved, dict):
            saved = {}
        matches = all(saved.get(key) == value for key, value in simple.items())
        self.step("QUEST-003", "Verify interview answer persistence",
                  "PASS" if matches else "FAIL", f"Matched {len(saved)} saved answers to {len(simple)} submitted")
        if not matches:
            self.reason = "Interview answers do not match data reloaded from the API"
        return matches

    def submit_assets(self):
        if self.case.get("status") != "scoping_in_progress":
            return True
        if "assets" in self.completed_actions:
            self.step("ASSET-001", "Previously submitted asset profiles", "SKIP",
                      "Resuming from checkpoint; no duplicate POST /assets")
            return True
        profiles = self.asset_profiles
        if profiles is None:
            diagram = self.case.get("diagram") or {}
            profiles = diagram.get("asset_profiles") or []
        if not isinstance(profiles, list) or not profiles:
            self.reason = "No asset profiles available; supply --assets path/to/profiles.json"
            self.step("ASSET-001", "Asset profiling", "BLOCKED", self.reason)
            return False
        if not self.write_and_verify("ASSET-001", "Submit and persist reviewed asset profiles",
                                     "POST", "/assets", {"asset_profiles": profiles},
                                     action_key="assets"):

            return False
        stored_profiles = (self.case.get("diagram") or {}).get("asset_profiles") or []
        self.step("ASSET-002", "Verify asset profile persistence",
                  "PASS" if len(stored_profiles) >= len(profiles) else "FAIL",
                  f"Submitted {len(profiles)}, returned {len(stored_profiles)}")
        if len(stored_profiles) < len(profiles):
            self.reason = "Persisted asset profile count smaller than submitted"
            return False
        return True

    def inspect_controls(self):
        controls = self.case.get("controls")
        if not isinstance(controls, list):
            self.reason = "Missing control list in case response"
            self.step("CTRL-003", "Inspect assigned controls", "FAIL", self.reason)
            return False
        self.step("CTRL-003", "Inspect scoped control set", "PASS",
                  "Controls: " + str(len(controls)) + "; set correctness requires known baseline")
        if self.test_controls:
            if "controls" in self.completed_actions:
                self.step("CTRL-007", "Previously tested control PATCH", "SKIP",
                          "Resuming from checkpoint")
                return True
            return self.write_and_verify("CTRL-007", "Re-save existing control scope",
                                         "PATCH", "/controls", {"controls": controls},
                                         expected_field="controls", expected_value=controls,
                                         action_key="controls")
        self.step("CTRL-007", "Control PATCH not requested", "SKIP", "Use --test-controls")
        return True

    def submit_questionnaire(self):
        if self.case.get("status") not in ("scoping_in_progress", "gap_response_pending"):
            return True
        questionnaire = self.case.get("questionnaire") or {}
        questions = questionnaire.get("questions") or []
        if not isinstance(questions, list) or not questions:
            self.reason = "Questionnaire questions not available; cannot submit responses"
            self.step("QUEST-001", "Generate questionnaire questions", "BLOCKED", self.reason)
            return False
        answers, missing = gather_answers(questions, self.supplied, "questionnaire", self.interactive)
        if missing:
            self.pause_answers("Questionnaire", questions, "questionnaire", missing)
            return False
        payload = questionnaire_payload(questions, answers)
        if not self.write_and_verify("QUEST-003", "Submit questionnaire responses",
                                     "POST", "/questionnaire", payload,
                                     expected_status="gap_analysis"):
            return False
        qdata = self.case.get("questionnaire") or {}
        saved = qdata.get("submitted_responses") or []
        if not isinstance(saved, list):
            saved = []
        matching = 0
        for expected in payload["responses"]:
            for actual in saved:
                if (isinstance(actual, dict) and
                        actual.get("question_id") == expected.get("question_id") and
                        str(actual.get("asset_id") or "") == str(expected.get("asset_id") or "") and
                        actual.get("response") == expected.get("response")):
                    matching += 1
                    break
        ok = matching == len(payload["responses"])
        self.step("QUEST-003", "Verify questionnaire response persistence",
                  "PASS" if ok else "FAIL",
                  f"Matching submitted responses: {matching}/{len(payload['responses'])}")
        if not ok:
            self.reason = "Questionnaire responses do not match data reloaded from the API"
        return ok

    def inspect_gap(self):
        if self.case.get("status") != "gap_analysis":
            self.reason = "Expected gap_analysis boundary, observed " + str(self.case.get("status"))
            self.step("VALID-001", "Reach GAP analysis", "BLOCKED", self.reason)
            return False
        gap = self.case.get("gap_analysis") or {}
        self.step("VALID-001", "Reach GAP analysis workflow boundary", "PASS",
                  "Status: " + str(self.case.get("status")))
        results = gap.get("results") or {}
        self.step("VALID-001", "Inspect preliminary GAP result structure",
                  "PASS" if isinstance(results, dict) else "FAIL",
                  "Review status: " + str(gap.get("status")) + "; execution/validation not covered")
        self.step("VALID-002", "Advisor validation not yet implemented", "SKIP",
                  "No validation write endpoint provided; not executed")
        self.reason = "Reached planned stopping point: GAP analysis (validation not implemented)"
        return True

    def run(self, simulate=False, ritm=None, simulated=False):
        try:
            if simulate:
                if not self.create_simulated():
                    return False
            else:
                self.ritm = ritm
                self.simulated = simulated
            if not self.get_case():
                return False
            if self.case.get("status") == "complete":
                self.reason = "Case already complete; no write tests attempted"
                self.step("ASSESS-003", "No changes to completed case", "SKIP", self.reason)
                return False
            if not self.advance_intake():
                return False
            if not self.submit_interview():
                return False
            if self.case.get("status") == "scoping_in_progress":
                if not self.submit_assets():
                    return False
                if not self.inspect_controls():
                    return False
            if not self.submit_questionnaire():
                return False
            if self.case.get("status") == "gap_analysis":
                return self.inspect_gap()
            self.reason = "Unexpected workflow state: " + str(self.case.get("status"))
            self.step("ASSESS-003", "Workflow state check", "BLOCKED", self.reason)
            return False
        finally:
            self.report()


def main(argv=None):
    parser = argparse.ArgumentParser(description="CSCA Centre interactive E2E workflow (write-enabled)")
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--simulate", action="store_true", help="Create an isolated mock RITM (requires enabled test endpoint)")
    source.add_argument("--ritm", help="Existing TEST case RITM; requires --confirm-ritm")
    source.add_argument("--resume", metavar="CHECKPOINT", help="Resume an earlier E2E test by checkpoint")
    parser.add_argument("--allow-write", action="store_true", help="Required acknowledgement for writes")
    parser.add_argument("--confirm-ritm", help="Repeat existing RITM exactly to authorize writes")
    parser.add_argument("--base-url", default=os.getenv("CSCA_BASE_URL"), help="e.g. https://host/libraries/v1")
    parser.add_argument("--bearer", action="store_true", help="Use bearer token rather than X-CSCA-Library-Key")
    parser.add_argument("--insecure", action="store_true", help="Disable TLS certificate verification (test only)")
    parser.add_argument("--ca-bundle", help="Trusted corporate CA PEM bundle")
    parser.add_argument("--team", help="Service team to assign when completing triage")
    parser.add_argument("--answers", metavar="JSON", help="Synthetic interview/questionnaire answers")
    parser.add_argument("--assets", metavar="JSON", help="Full list of synthetic asset profiles")
    parser.add_argument("--interactive", action="store_true", help="Prompt for missing answers")
    parser.add_argument("--test-controls", action="store_true", help="Re-save existing control scope with PATCH")
    parser.add_argument("--report-dir", default="e2e_reports", help="Where to save reports/checkpoints")
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--timeout", type=int, default=30)
    args = parser.parse_args(argv)
    if not args.allow_write:
        parser.error("Writes require --allow-write; run only in an authorized test environment")
    key = os.getenv("CSCA_BEARER_TOKEN" if args.bearer else "CSCA_LIBRARY_KEY")
    if not args.base_url or not key:
        parser.error("Set CSCA_BASE_URL and CSCA_LIBRARY_KEY (or CSCA_BEARER_TOKEN)")
    if args.insecure and args.ca_bundle:
        parser.error("Choose --insecure or --ca-bundle, not both")
    saved = {}
    if args.resume:
        try:
            saved = read_json(args.resume)
        except (OSError, ValueError) as exc:
            parser.error("Cannot load checkpoint: " + str(exc))
        if not isinstance(saved, dict) or not saved.get("ritm"):
            parser.error("Checkpoint does not contain a RITM")
    ritm = args.ritm or saved.get("ritm")
    simulated = bool(saved.get("simulated"))
    if ritm and not simulated and args.confirm_ritm != ritm:
        parser.error("For an existing case, repeat its ID with --confirm-ritm EXACT_ID")
    answers = read_json(args.answers) if args.answers else {}
    assets = read_json(args.assets) if args.assets else None
    if isinstance(assets, dict):
        assets = assets.get("asset_profiles")
    if assets is not None and not isinstance(assets, list):
        parser.error("--assets must be a list or an object with asset_profiles list")
    if not isinstance(answers, dict):
        parser.error("--answers must contain a JSON object")
    if args.insecure:
        print("WARNING: TLS certificate verification disabled for this test session")
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    api = CaseApi(args.base_url, key, bearer=args.bearer, insecure=args.insecure,
                  ca_bundle=args.ca_bundle, timeout=args.timeout)
    runner = E2ERunner(api, args.report_dir, interactive=args.interactive,
                       supplied=answers, team=args.team, asset_profiles=assets,
                       test_controls=args.test_controls, verbose=args.verbose,
                       completed_actions=saved.get("completed_actions", []))
    return 0 if runner.run(simulate=args.simulate, ritm=ritm, simulated=simulated) else 1


if __name__ == "__main__":
    sys.exit(main())
