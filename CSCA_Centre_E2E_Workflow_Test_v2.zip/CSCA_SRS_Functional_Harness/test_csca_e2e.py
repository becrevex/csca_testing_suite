"""Offline tests for the CSCA write-enabled E2E harness. No external requests."""
import json
import tempfile
import unittest
from pathlib import Path
from copy import deepcopy
from unittest.mock import patch

from csca_e2e_test import (CaseApi, E2ERunner, answer_for, gather_answers,
                           parse_interactive, questionnaire_payload)


class FakeApi:
    """Small in-memory stand-in for the documented Case API."""
    def __init__(self):
        self.requests = []
        self.case = {
            "ritm": "RITM9999999-MOCK", "case_id": "uuid-synthetic",
            "status": "triage", "service_team": "Cloud",
            "interview": {"questions": [
                {"question_id": "PQ-001", "question": "Test synthetic gate?"},
                {"question_id": "IT-AC-07", "question": "Test another synthetic gate?"}],
                "submitted_answers": {}},
            "diagram": {"asset_profiles": [{"id": "synthetic-asset-1", "asset_type": "Server",
                                            "asset_name": "Lab server", "quantity": 1}]},
            "assets": [], "controls": ["IT-AC-02"],
            "questionnaire": {"questions": [{"question_id": "Q-1", "asset_id": "synthetic-asset-1",
                                             "attestation_question": "Synthetic attestation?"}],
                              "submitted_responses": []},
            "gap_analysis": {"status": "pending", "results": {"total_control_gaps": 0}}
        }

    def call(self, method, path, payload=None):
        self.requests.append((method, path, deepcopy(payload)))
        if method == "POST" and path == "/cases/simulate":
            return 201, deepcopy(self.case), "", 1.0
        if method == "GET" and path == "/cases/RITM9999999-MOCK":
            return 200, deepcopy(self.case), "", 1.0
        if method == "PATCH" and path.endswith("/controls"):
            self.case["controls"] = payload["controls"]
            return 200, deepcopy(self.case), "", 1.0
        if method == "PATCH" and path.endswith("RITM9999999-MOCK"):
            self.case.update(payload)
            return 200, deepcopy(self.case), "", 1.0
        if method == "POST" and path.endswith("/interview"):
            self.case["interview"]["submitted_answers"] = payload["answers"]
            self.case["status"] = "scoping_in_progress"
            return 200, deepcopy(self.case), "", 1.0
        if method == "POST" and path.endswith("/assets"):
            self.case["diagram"]["asset_profiles"] = payload["asset_profiles"]
            self.case["assets"] = [dict(asset_id=a["id"], asset_type=a["asset_type"])
                                   for a in payload["asset_profiles"]]
            return 200, deepcopy(self.case), "", 1.0
        if method == "POST" and path.endswith("/questionnaire"):
            self.case["questionnaire"]["submitted_responses"] = payload["responses"]
            self.case["status"] = "gap_analysis"
            return 200, deepcopy(self.case), "", 1.0
        return 404, {"message": "Not found in mock"}, "", 1.0


class E2ETests(unittest.TestCase):
    def test_answer_key_with_asset(self):
        found, value = answer_for({"question_id": "Q-1", "asset_id": "A"},
                                  {"questionnaire": {"A|Q-1": "Yes"}}, "questionnaire")
        self.assertTrue(found)
        self.assertEqual(value, "Yes")

    def test_missing_answers_not_guessed(self):
        got, missing = gather_answers([{"question_id": "Q1"}], {}, "interview")
        self.assertEqual(got, {})
        self.assertEqual(missing, ["Q1"])

    def test_prompt_replaces_null_template(self):
        with patch("builtins.input", return_value="yes"):
            got, missing = gather_answers([{"question_id": "Q1"}],
                                          {"interview": {"Q1": None}}, "interview", True)
        self.assertEqual(got, {"Q1": True})
        self.assertEqual(missing, [])

    def test_parse_bool_and_options(self):
        self.assertFalse(parse_interactive("no", {}))
        self.assertTrue(parse_interactive("yes", {}))
        self.assertEqual(parse_interactive("2", {"options": ["A", "B"]}), "B")

    def test_questionnaire_payload(self):
        qs = [{"question_id": "Q", "asset_id": "A"}]
        data = questionnaire_payload(qs, {"A|Q": {"response": True, "artifacts": []}})
        self.assertEqual(data, {"responses": [{"question_id": "Q", "asset_id": "A",
                                              "response": True, "artifacts": []}]})

    def test_full_workflow_simulated(self):
        with tempfile.TemporaryDirectory() as tmp:
            fake = FakeApi()
            runner = E2ERunner(fake, tmp, supplied={
                "interview": {"PQ-001": True, "IT-AC-07": False},
                "questionnaire": {"synthetic-asset-1|Q-1": True}},
                test_controls=True)
            self.assertTrue(runner.run(simulate=True))
            self.assertEqual(runner.case["status"], "gap_analysis")
            self.assertEqual(runner.ritm, "RITM9999999-MOCK")
            self.assertTrue(any(s[0:2] == ("POST", "/cases/RITM9999999-MOCK/questionnaire")
                                for s in fake.requests))
            self.assertTrue(Path(tmp, "CSCA_E2E_RITM9999999-MOCK_checkpoint.json").exists())
            self.assertFalse(any(s[1] == "/cases/RITM9999999-MOCK/reports"
                                 for s in fake.requests))
            self.assertTrue(any(s["step"] == "Verify questionnaire response persistence" and
                                s["result"] == "PASS" for s in runner.steps))

    def test_pause_and_templates(self):
        with tempfile.TemporaryDirectory() as tmp:
            fake = FakeApi()
            runner = E2ERunner(fake, tmp)
            self.assertFalse(runner.run(simulate=True))
            self.assertTrue(Path(tmp, "CSCA_E2E_RITM9999999-MOCK_answers_template.json").exists())
            self.assertTrue(Path(tmp, "CSCA_E2E_RITM9999999-MOCK_interview_questions.json").exists())
            self.assertEqual(fake.case["status"], "intake_interview")
            self.assertFalse(any(path.endswith("/interview") for _, path, _ in fake.requests))

    def test_resume_after_answer_pause(self):
        with tempfile.TemporaryDirectory() as tmp:
            fake = FakeApi()
            runner1 = E2ERunner(fake, tmp)
            self.assertFalse(runner1.run(simulate=True))
            runner2 = E2ERunner(fake, tmp, supplied={"interview": {"PQ-001": True,
                                                                     "IT-AC-07": False},
                                                         "questionnaire": {"synthetic-asset-1|Q-1": True}})
            self.assertTrue(runner2.run(ritm="RITM9999999-MOCK", simulated=True))

    def test_resume_does_not_resubmit_assets(self):
        with tempfile.TemporaryDirectory() as tmp:
            fake = FakeApi()
            runner1 = E2ERunner(fake, tmp, supplied={
                "interview": {"PQ-001": True, "IT-AC-07": False}})
            self.assertFalse(runner1.run(simulate=True))
            checkpoint = json.loads(Path(tmp, "CSCA_E2E_RITM9999999-MOCK_checkpoint.json").read_text())
            self.assertIn("assets", checkpoint["completed_actions"])
            runner2 = E2ERunner(fake, tmp, supplied={
                "questionnaire": {"synthetic-asset-1|Q-1": True}},
                completed_actions=checkpoint["completed_actions"])
            self.assertTrue(runner2.run(ritm=checkpoint["ritm"], simulated=True))
            asset_calls = [x for x in fake.requests if x[0] == "POST" and x[1].endswith("/assets")]
            self.assertEqual(len(asset_calls), 1)

    def test_complete_case_never_written(self):
        with tempfile.TemporaryDirectory() as tmp:
            fake = FakeApi()
            fake.case["status"] = "complete"
            runner = E2ERunner(fake, tmp)
            self.assertFalse(runner.run(ritm="RITM9999999-MOCK", simulated=True))
            self.assertEqual([x[0] for x in fake.requests], ["GET"])

    def test_blocked_transition_stops(self):
        class BlockedApi(FakeApi):
            def call(self, method, path, payload=None):
                if method == "PATCH" and path == "/cases/RITM9999999-MOCK":
                    return 409, {"message": "Required approval missing"}, "", 1
                return super().call(method, path, payload)
        with tempfile.TemporaryDirectory() as tmp:
            runner = E2ERunner(BlockedApi(), tmp)
            self.assertFalse(runner.run(simulate=True))
            self.assertTrue(any(s["result"] == "BLOCKED" for s in runner.steps))

    def test_malformed_questionnaire_storage_is_not_pass(self):
        class DiscardingApi(FakeApi):
            def call(self, method, path, payload=None):
                result = super().call(method, path, payload)
                if method == "POST" and path.endswith("/questionnaire"):
                    self.case["questionnaire"]["submitted_responses"] = []
                return result
        with tempfile.TemporaryDirectory() as tmp:
            runner = E2ERunner(DiscardingApi(), tmp, supplied={
                "interview": {"PQ-001": True, "IT-AC-07": False},
                "questionnaire": {"synthetic-asset-1|Q-1": True}})
            self.assertFalse(runner.run(simulate=True))
            self.assertTrue(any(s["step"] == "Verify questionnaire response persistence" and
                                s["result"] == "FAIL" for s in runner.steps))


if __name__ == "__main__":
    unittest.main()
