"""Offline checks for the SRS harness. No network or credentials required."""
import io
import json
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path

from csca_srs_test import Api, SrsHarness, deep_value, load_matrix, main, values_as_set

HERE = Path(__file__).resolve().parent
CASE = HERE / "fixtures" / "sample_case_demo.json"
BASELINE = HERE / "fixtures" / "baseline.demo.json"
MATRIX = HERE / "srs_traceability.csv"


class FakeResponse:
    def __init__(self, status, data):
        self.status_code = status
        self.data = data
    def json(self):
        return self.data


class FakeSession:
    def __init__(self, case):
        self.headers = {}
        self.case = case
        self.urls = []
    def get(self, url, params=None, timeout=30, verify=True):
        self.urls.append((url, params, verify))
        if url.endswith("/cases/" + self.case["ritm"]):
            return FakeResponse(200, self.case)
        if url.endswith("/cases"):
            return FakeResponse(200, {"items": [{"ritm": self.case["ritm"]}]})
        if url.endswith("/controls"):
            return FakeResponse(200, {"items": [{"control_id": "IT-AC-02", "version": 1,
                "revision_id": "rev1", "attributes": [{"attribute_id": "IT-AC-02-a"}]}]})
        if url.endswith("/shared-services"):
            return FakeResponse(200, {"items": []})
        if url.endswith("-openapi.json"):
            return FakeResponse(200, {"openapi": "3.1.0", "info": {"version": "1.0.0"}})
        return FakeResponse(404, {"error": "not_found"})


class SrsTests(unittest.TestCase):
    def setUp(self):
        self.case = json.loads(CASE.read_text(encoding="utf-8"))
        self.baseline = json.loads(BASELINE.read_text(encoding="utf-8"))
        self.matrix = load_matrix(MATRIX)

    def make_harness(self, case=None, baseline=None, offline=True):
        case = case or self.case
        if offline:
            h = SrsHarness(self.matrix, case["ritm"], baseline=baseline or {}, case_file=str(CASE))
            h.case = case
            h.fetch_case = lambda: True
        else:
            session = FakeSession(case)
            api = Api("https://example.test/libraries/v1", "secret", session=session)
            h = SrsHarness(self.matrix, case["ritm"], api=api, baseline=baseline or {})
        return h

    def run_quiet(self, h):
        with redirect_stdout(io.StringIO()):
            self.assertTrue(h.run())
        return h

    def test_unique_requirement_ids(self):
        self.assertEqual(len(self.matrix), 77)
        self.assertEqual(len(set(r["id"] for r in self.matrix)), 77)

    def test_srs_titles_grounded(self):
        x = next(r for r in self.matrix if r["id"] == "CTRL-003")
        self.assertIn("deterministically", x["title"])

    def test_offline_identity(self):
        h = self.run_quiet(self.make_harness())
        self.assertTrue(any(x["requirement"] == "ASSESS-001" and x["result"] == "PASS" for x in h.tests))

    def test_offline_has_nontested_instead_of_false_pass(self):
        h = self.run_quiet(self.make_harness())
        coverage = {r["id"]: r["status"] for r in h.coverage()}
        self.assertEqual(coverage["SEC-002"], "NOT_TESTED")
        self.assertEqual(coverage["CTRL-003"], "PARTIAL")

    def test_workbook_expected_values(self):
        h = self.run_quiet(self.make_harness(baseline=self.baseline))
        comp = [x for x in h.tests if x["kind"] == "baseline"]
        self.assertGreaterEqual(len(comp), 10)
        self.assertTrue(all(x["result"] == "PASS" for x in comp))

    def test_wrong_risk_tier_fails(self):
        baseline = json.loads(json.dumps(self.baseline))
        baseline["expected"]["risk_tier"] = "Tier 1"
        h = self.run_quiet(self.make_harness(baseline=baseline))
        self.assertTrue(any(x["kind"] == "baseline" and x["result"] == "FAIL" for x in h.tests))
        self.assertEqual(next(x for x in h.coverage() if x["id"] == "ASSESS-004")["status"], "FAIL")

    def test_question_pairs_include_asset(self):
        baseline = json.loads(json.dumps(self.baseline))
        baseline["expected"]["question_pairs"] = [["wrong-asset", "IT-AC-02-a"]]
        h = self.run_quiet(self.make_harness(baseline=baseline))
        self.assertTrue(any(x["test"] == "Asset/question pairs match workbook baseline" and x["result"] == "FAIL" for x in h.tests))

    def test_gaps_are_checked(self):
        h = self.run_quiet(self.make_harness(baseline=self.baseline))
        self.assertEqual(len([x for x in h.tests if x["test"].startswith("GAP result ")]), 2)

    def test_missing_csca_field_fails_not_skips(self):
        case = json.loads(json.dumps(self.case))
        del case["intake"]["data_classification"]
        h = self.run_quiet(self.make_harness(case=case))
        self.assertTrue(any(x["requirement"] == "INTAKE-005" and x["result"] == "FAIL" for x in h.tests))

    def test_malformed_risk_baseline_rejected(self):
        baseline = {"ritm": "RITM9999999", "expected": {"risk_tier": "Tier 2"}}
        h = self.make_harness(baseline=baseline)
        with redirect_stdout(io.StringIO()):
            self.assertFalse(h.run())
        self.assertIn("Baseline RITM must equal", h.problems[0])

    def test_api_stub_works(self):
        h = self.run_quiet(self.make_harness(baseline=self.baseline, offline=False))
        self.assertEqual(len(h.api.calls), 6)
        self.assertTrue(any(x["requirement"] == "INTEG-006" and x["result"] == "PASS" for x in h.tests))

    def test_api_never_writes(self):
        h = self.run_quiet(self.make_harness(offline=False))
        self.assertTrue(all(x["method"] == "GET" for x in h.api.calls))

    def test_bad_case_ritm_fails(self):
        case = json.loads(json.dumps(self.case))
        case["ritm"] = "RITM0000000"
        h = self.make_harness(case=case)
        h.ritm = "RITM1234567"
        self.run_quiet(h)
        self.assertTrue(any(x["test"] == "RITM identity" and x["result"] == "FAIL" for x in h.tests))

    def test_invalid_field_path(self):
        self.assertEqual(deep_value(self.case, "questionnaire.questions.99.id"), (False, None))

    def test_sets_dedupe(self):
        self.assertEqual(values_as_set(["A", "A", "B"]), {"A", "B"})

    def test_report_generation(self):
        h = self.run_quiet(self.make_harness(baseline=self.baseline))
        with tempfile.TemporaryDirectory() as folder:
            report = h.reports(folder)
            for field in ("text", "json", "csv"):
                self.assertTrue(report[field].exists())
            output = json.loads(report["json"].read_text(encoding="utf-8"))
            self.assertEqual(len(output["requirements"]), 77)
            self.assertNotIn("secret", report["text"].read_text(encoding="utf-8"))

    def test_cli_offline(self):
        with tempfile.TemporaryDirectory() as folder, redirect_stdout(io.StringIO()):
            status = main(["--ritm", "RITM1234567", "--case-file", str(CASE),
                           "--baseline", str(BASELINE), "--out-dir", folder])
            self.assertEqual(status, 0)
            self.assertEqual(len(list(Path(folder).glob("*.csv"))), 1)


if __name__ == "__main__":
    unittest.main()
