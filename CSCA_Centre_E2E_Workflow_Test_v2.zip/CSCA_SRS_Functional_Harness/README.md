# CSCA Centre — Requirements-Driven Functional Test Harness

**Source of truth:** `CSCA Platform — Software Requirements Specification`, **CSCA-SRS-001 v1.0** (36-page Word document supplied November 23, 2026). API mappings were derived from the supplied `csca_cases_api_helper.txt` and `csca_libraries_api_helper.txt` (Case/Library API v1.0.0, OAS 3.1).

This is **Phase 2**, separate from the initial `csca_test.py` API smoke/contract harness. This program asks whether a *case's outputs match the requirements and a known expected baseline*. It does **not** write or modify existing cases.

## Install and configure

Requires Python 3.10+ and `requests`:

```powershell
python -m pip install requests
$env:CSCA_BASE_URL = 'https://YOUR-HOST/libraries/v1'
$env:CSCA_LIBRARY_KEY = 'YOUR-AUTHORIZED-LIBRARY-KEY'
```

You can alternatively set `CSCA_BEARER_TOKEN` for Okta bearer authentication. Never put credentials in the JSON baseline, on the command line, or in the report.

If Python rejects your company's TLS certificate, use the approved PEM CA bundle:

```powershell
$env:CSCA_CA_BUNDLE = 'C:\Certificates\company-ca.pem'
```

For a **temporary authorized troubleshooting run only**, `--insecure` disables certificate validation. It exposes the connection to server impersonation/credential interception, so use it only on an isolated trusted test environment and remove it afterward.

## 1. Run read-only functional checks for an existing RITM

```powershell
python .\csca_srs_test.py --ritm RITM1234567 --verbose
```

The script retrieves `GET /cases/{ritm}`, checks `GET /cases?ritm=...`, reads the first page of the control and shared-service catalogs, and fetches both published OpenAPI documents. **No POST, PATCH, or DELETE calls are made.**

The harness produces timestamped text, JSON, and CSV traceability reports under `csca_srs_results/`.

## 2. Compare against expected CSCA workbook outcomes

This is where the actual business-logic tests become valuable. Create a baseline for the specific RITM using independently verified expected outputs from the legacy CSCA workbook. The included `fixtures/baseline.demo.json` is **fictional demonstration data** and must not be used as a real production oracle.

Supported `expected` fields:

| Expected field | Requirement(s) | What is checked |
|---|---|---|
| `risk_tier` | ASSESS-004 | Exact final tier matches expected |
| `assessment_type` | INTAKE-002 | Exact service type matches |
| `lir_qualifies` | ASSESS-006 | Exact boolean eligibility matches |
| `control_ids` | CTRL-003 | Exact set of scoped controls matches, including unexpected/missing |
| `asset_types` | ASSET-004 | Exact set of asset types matches |
| `asset_control_map` | CTRL-003 | Exact per-asset control IDs match |
| `question_ids` | QUEST-001 | Exact set of question IDs matches |
| `question_pairs` | QUEST-001 | Exact set of `[asset_id, question_id]` pairs matches (handles the asset-central model) |
| `gap_totals` | VALID-001 | Exact counts of control gaps and required artifacts match |
| `validation_outcomes` | VALID-002 | Expected `asset_id\|question_id` to validation status mapping |
| `finding_codes` | FIND-001 | Exact finding-code set matches |

You can also assert any field in the documented full-case response using `assertions`. Supported assertion operators: `equals`, `not_empty`, `contains`. Each assertion must cite an **actual SRS requirement ID** and a dotted JSON field path:

```json
{
  "ritm": "RITM1234567",
  "expected": {
    "risk_tier": "Tier 2",
    "control_ids": ["IT-AC-02", "IT-CO-16"],
    "question_pairs": [["srv-01", "IT-AC-02-a"]]
  },
  "assertions": [
    {
      "requirement": "INTAKE-001",
      "name": "Project name preserved",
      "path": "intake.project_name",
      "operator": "equals",
      "expected": "Example App"
    }
  ]
}
```

Run it:

```powershell
python .\csca_srs_test.py --ritm RITM1234567 --baseline .\baseline.RITM1234567.json --verbose
```

Baseline RITM mismatch is rejected to prevent accidentally testing the wrong case.

## 3. Verify the harness offline (no credentials, no network)

The package includes a completely **synthetic** full-case example and its matching baseline:

```powershell
python .\csca_srs_test.py --ritm RITM1234567 `
  --case-file .\fixtures\sample_case_demo.json `
  --baseline .\fixtures\baseline.demo.json `
  --out-dir .\demo_results --verbose
```

Run unit tests:

```powershell
python -m unittest -v test_csca_srs.py
```

## Report interpretation

The report includes **all 77 unique SRS requirements**, even if the supplied APIs cannot prove them. The specification's traceability summary repeats some entries; those duplicates were removed by stable requirement ID.

- **PASS (assertion):** The specific tested statement held for the retrieved case. It is *not* an assertion that the entire requirement is implemented.
- **FAIL (assertion or requirement):** A tested expectation was contradicted.
- **PARTIAL (requirement):** At least one assertion passed; the entire requirement is **not** proven. A single successful sample does not establish universal business correctness.
- **NOT_TESTED (requirement):** There was no executable evidence for this requirement with the available API and fixtures.

The three report files are:

- `CSCA_SRS_<RITM>_<UTC>.txt` — human-readable summary, aligned checks, failures.
- `CSCA_SRS_<RITM>_<UTC>.json` — test evidence, requirements, HTTP timing metadata. No auth headers or complete case JSON are saved.
- `CSCA_SRS_<RITM>_<UTC>_traceability.csv` — one row per requirement with its status, recommended test approach, and missing evidence.

## What cannot be declared passed from a read-only RITM

The SRS requires immutability of audit trails, workflow transition enforcement, Classic vs. asset-central questionnaire generation, actual persistence across saves/restarts, evidence integrity, RBAC/SSO, outbound GRC integration, browser parity, backups, and p95 performance under load. Those require dedicated test fixtures, test users, a controlled simulated RITM, environment access, or explicit write authorization. They remain visible in the matrix instead of receiving fabricated PASS results.

**Notable specification/API questions to resolve with AIEO:**

1. The SRS lists granular lifecycle phases (including issue management, summary review, closed complete/incomplete); the Case API currently documents seven high-level `status` values. Determine whether these correspond to `status`, `current_phase`, or another persisted field.
2. The SRS requires **Classic and asset-central** questionnaires (`QUEST-002`); a corresponding explicit model-selection endpoint is not evident in the two supplied API reference extracts.
3. The SRS requires an **append-only queryable audit trail** (`ASSESS-007`, `DATA-002`); a dedicated audit-query endpoint is not evident in the supplied reference extracts.
4. The SRS says service-to-service calls must use **short-lived credentials** (`SEC-004`), while the API documentation offers `X-CSCA-Library-Key` and Okta bearer tokens. Ask whether the key is short-lived/managed or used only for a transitional test path.
5. No explicit validation execution endpoint was identified in the two API reference extracts; a returned control-test structure by itself is not proof that validation logic was correctly executed.
6. `GET /controls` currently returns only a **first page (maximum 200)**. A full catalog/export is required to prove the entire CCF version and control applicability matrix; the harness doesn't claim full-catalog coverage from the sample.

## Security and engineering notes

- Read-only by design. The only request method implemented is GET.
- TLS verification is **on** by default; `--ca-bundle` and `--insecure` are explicit settings.
- Never save production sensitive case payloads without appropriate corporate storage and retention controls.
- No LLM, pytest dependency, browser automation, or external service is required.
- Library catalog, SRS and baseline checks are intentionally simple `if`/`for` tests to keep code review straightforward.
- This is a **test development and traceability artifact**, not proof of production compliance.

## Controlled write-enabled end-to-end test

A separate **`csca_e2e_test.py`** executable drives simulated cases through the documented Case API lifecycle up to GAP analysis, stopping before validation. It requires `--allow-write` and does not guess questionnaire answers. See **`README_E2E.md`** for safety guardrails, CLI commands, interactive answers, resumption, and reporting.
