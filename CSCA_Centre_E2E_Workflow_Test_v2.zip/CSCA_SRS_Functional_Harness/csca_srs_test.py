"""CSCA Centre SRS functional-test harness (read-only).

Designed against CSCA-SRS-001 v1.0 and the Case/Library API reference files.
A PASS means an individual test assertion passed, not that the entire SRS is met.
"""

import argparse
import csv
import json
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote

import requests


HERE = Path(__file__).resolve().parent
VALID_STATUSES = {"triage", "ready_to_work", "intake_interview", "scoping_in_progress",
                  "gap_response_pending", "gap_analysis", "complete"}


def now_utc():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def utc_stamp():
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%SZ")


def nonempty(value):
    return value is not None and value != "" and value != [] and value != {}


def values_as_set(values, key=None):
    """Return a set of non-empty IDs/names, accepting a list of strings or dicts."""
    result = set()
    for value in values or []:
        if isinstance(value, dict):
            value = value.get(key) if key else None
        if nonempty(value):
            result.add(str(value))
    return result


def deep_value(obj, name):
    """Read a.b.c or a.0.b from dict/list objects. Return (found, value)."""
    current = obj
    for part in name.split("."):
        if isinstance(current, dict) and part in current:
            current = current[part]
        elif isinstance(current, list) and part.isdigit() and int(part) < len(current):
            current = current[int(part)]
        else:
            return False, None
    return True, current


def short(value, limit=130):
    if isinstance(value, (dict, list)):
        value = json.dumps(value, ensure_ascii=False, default=str)
    else:
        value = str(value)
    value = " ".join(value.split())
    if len(value) > limit:
        return value[:limit - 3] + "..."
    return value


class Api:
    def __init__(self, base_url, token, bearer=False, ca_bundle=None, insecure=False,
                 timeout=30, session=None):
        self.base_url = base_url.rstrip("/")
        self.session = session if session is not None else requests.Session()
        self.session.headers.update({"Accept": "application/json"})
        if bearer:
            self.session.headers["Authorization"] = "Bearer " + token
        else:
            self.session.headers["X-CSCA-Library-Key"] = token
        self.verify = False if insecure else (ca_bundle or True)
        self.timeout = timeout
        self.calls = []

    def get(self, path, params=None):
        started = time.monotonic()
        try:
            response = self.session.get(self.base_url + path, params=params,
                                        timeout=self.timeout, verify=self.verify)
            elapsed_ms = round((time.monotonic() - started) * 1000, 1)
            self.calls.append({"method": "GET", "path": path, "status": response.status_code,
                               "duration_ms": elapsed_ms})
            try:
                data = response.json()
            except ValueError:
                data = None
            return response.status_code, data, "", elapsed_ms
        except requests.RequestException as exc:
            self.calls.append({"method": "GET", "path": path, "status": None,
                               "duration_ms": None, "error": type(exc).__name__})
            return None, None, str(exc), None


def load_matrix(path):
    with open(path, newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def check_outcome(ok):
    return "PASS" if ok else "FAIL"


class SrsHarness:
    def __init__(self, matrix, ritm, api=None, baseline=None, case_file=None, verbose=False):
        self.matrix = matrix
        self.ritm = ritm
        self.api = api
        self.baseline = baseline or {}
        self.case_file = case_file
        self.verbose = verbose
        self.tests = []
        self.case = None
        self.controls_catalog = None
        self.shared_catalog = None
        self.list_items = None
        self.problems = []

    def add(self, requirement, name, status, detail, kind="structural"):
        row = {"requirement": requirement, "test": name, "result": status,
               "kind": kind, "detail": detail}
        self.tests.append(row)
        print(f"{requirement:<13} {status:<11} {name}")
        if self.verbose and detail:
            print(" " * 26 + short(detail, 240))

    def check(self, rid, name, ok, detail, kind="structural"):
        self.add(rid, name, check_outcome(ok), detail, kind)

    def omitted(self, rid, name, reason):
        self.add(rid, name, "NOT_TESTED", reason)

    def fetch_case(self):
        if self.case_file:
            try:
                case = json.loads(Path(self.case_file).read_text(encoding="utf-8-sig"))
            except (OSError, ValueError) as exc:
                self.problems.append("Cannot load case file: " + str(exc))
                return False
            if not isinstance(case, dict):
                self.problems.append("Offline case JSON must be an object")
                return False
            self.case = case
            return True
        if not self.api:
            self.problems.append("No API connection configured")
            return False
        path = "/cases/" + quote(self.ritm, safe="")
        status, data, error, _ = self.api.get(path)
        if status != 200 or not isinstance(data, dict):
            self.problems.append(f"GET {path}: {error or 'HTTP ' + str(status)}")
            return False
        self.case = data
        status, data, error, _ = self.api.get("/cases", params={"ritm": self.ritm})
        if status == 200 and isinstance(data, dict) and isinstance(data.get("items"), list):
            self.list_items = data["items"]
        else:
            self.problems.append("RITM-filter list query unavailable: " + (error or str(status)))
        return True

    def fetch_catalogs(self):
        if not self.api:
            return
        for path, attr in (("/controls", "controls_catalog"),
                           ("/shared-services", "shared_catalog")):
            status, data, error, _ = self.api.get(path, params={"limit": 200, "offset": 0})
            if status == 200 and isinstance(data, dict) and isinstance(data.get("items"), list):
                setattr(self, attr, data["items"])
            else:
                self.problems.append("Cannot inspect " + path + ": " + (error or str(status)))

    def case_identity(self):
        case = self.case
        self.check("ASSESS-001", "RITM identity", case.get("ritm") == self.ritm,
                   f"expected={self.ritm}; observed={case.get('ritm')}")
        self.check("ASSESS-001", "Internal case identifier", nonempty(case.get("case_id")),
                   "case_id " + ("present" if nonempty(case.get("case_id")) else "missing"))
        if self.list_items is not None:
            matching = [x for x in self.list_items if isinstance(x, dict)
                        and x.get("ritm") == self.ritm]
            self.check("ASSESS-001", "Unique RITM in filtered results", len(matching) == 1,
                       f"Matching rows: {len(matching)}")
        else:
            self.omitted("ASSESS-001", "Unique RITM in filtered results",
                         "Requires live GET /cases?ritm=<RITM> response")

        for key in ("intake", "assets", "controls", "questionnaire", "findings"):
            self.check("ASSESS-002", "Assessment contains " + key,
                       key in case and isinstance(case[key], (dict, list)),
                       f"{key}: " + ("available" if key in case else "missing"))
        self.check("ASSESS-003", "Known lifecycle state", case.get("status") in VALID_STATUSES,
                   "Current state: " + str(case.get("status")))
        tier = case.get("tier_result") or {}
        if isinstance(tier, dict) and tier.get("base_tier") and tier.get("final_tier"):
            self.check("ASSESS-005", "Calculated and final tiers retained",
                       nonempty(tier.get("base_tier")) and nonempty(tier.get("final_tier")),
                       f"base={tier.get('base_tier')}; final={tier.get('final_tier')}")
            if nonempty(case.get("risk_tier")):
                self.check("ASSESS-005", "Final tier matches assessment",
                           case["risk_tier"] == tier["final_tier"],
                           f"risk_tier={case['risk_tier']}; final={tier['final_tier']}")
        else:
            self.omitted("ASSESS-005", "Calculated and adjusted tier preservation",
                         "No completed tier_result.base_tier / final_tier to compare")
        self.check("ASSESS-006", "LIR structure available",
                   isinstance(case.get("low_impact_release"), dict),
                   "low_impact_release object exists")
        self.check("DATA-001", "Assessment returned with related objects",
                   isinstance(case.get("intake"), dict) and isinstance(case.get("controls"), list),
                   "Read-side evidence only; durability requires a controlled write/re-read test")

    def intake_checks(self):
        intake = self.case.get("intake")
        if not isinstance(intake, dict):
            self.omitted("INTAKE-001", "Intake identity", "No intake object")
            return
        self.check("INTAKE-001", "Intake belongs to requested RITM", intake.get("ritm") == self.ritm,
                   f"intake.ritm={intake.get('ritm')}")
        self.check("INTAKE-002", "Assessment service classification exists",
                   nonempty(intake.get("assessment_type")),
                   f"assessment_type={intake.get('assessment_type')}")
        required_keys = ("business_criticality", "data_classification", "externally_facing",
                         "pii_data", "phi_data", "pci_data", "claims_data", "bank_data")
        present = [key for key in required_keys if key in intake]
        self.check("INTAKE-005", "Risk sensitivity inputs represented",
                   len(present) == len(required_keys),
                   "Missing keys: " + (", ".join(k for k in required_keys if k not in intake) or "none"))
        # This is not an intake-readiness check: missing data may be appropriate in triage.
        if self.case.get("status") not in ("triage", "ready_to_work"):
            fields = ("ritm", "advisor", "requested_for", "technical_poc", "project_name",
                      "assessment_type", "primary_application_service")
            missing = [key for key in fields if not nonempty(intake.get(key))]
            self.check("INTAKE-006", "Completed-intake core fields",
                       not missing, "Missing: " + (", ".join(missing) or "none"))
        else:
            self.omitted("INTAKE-006", "Completed-intake core fields",
                         "Case is still triage/ready_to_work; prerequisites may be incomplete")

    def assets_checks(self):
        assets = self.case.get("assets")
        if not isinstance(assets, list) or not assets:
            self.omitted("ASSET-001", "Scoped asset identifiers", "No scoped assets in this case")
            return
        missing = [index for index, asset in enumerate(assets) if not isinstance(asset, dict)
                   or not asset.get("asset_id") or not asset.get("asset_type")]
        self.check("ASSET-001", "Scoped assets have ID and type", not missing,
                   "Incomplete asset positions: " + str(missing))
        types = values_as_set(assets, "asset_type")
        self.check("ASSET-004", "Asset types are structured", len(types) > 0,
                   "Observed types: " + ", ".join(sorted(types)))
        profiles = (self.case.get("diagram") or {}).get("asset_profiles") or []
        if profiles:
            no_environment = [p.get("id") or str(index) for index, p in enumerate(profiles)
                              if not isinstance(p, dict) or not nonempty(p.get("environment"))]
            self.check("ASSET-006", "Asset profiles capture environment", not no_environment,
                       "Profiles missing environment: " + str(no_environment))
        else:
            self.omitted("ASSET-006", "Asset environments", "No diagram.asset_profiles available")

    def control_checks(self):
        controls = self.case.get("controls") or []
        scoped = values_as_set(controls)
        if controls:
            self.check("CTRL-003", "Scoped control IDs are nonempty and unique",
                       len(scoped) == len(controls),
                       f"IDs={len(controls)}; unique nonempty IDs={len(scoped)}")
        else:
            self.omitted("CTRL-003", "Scoped controls", "No scoped controls yet")
        if self.controls_catalog is None:
            self.omitted("CTRL-001", "Catalog record versioning", "Control catalog not retrieved")
            self.omitted("CTRL-005", "Control attribute decomposition", "Control catalog not retrieved")
            return
        if not self.controls_catalog:
            self.omitted("CTRL-001", "Catalog record versioning", "No controls returned")
            return
        missing_versions = [c.get("control_id") for c in self.controls_catalog
                            if not nonempty(c.get("version")) or not nonempty(c.get("revision_id"))]
        self.check("CTRL-001", "Control records include version/revision ID",
                   not missing_versions, "Missing version/revision: " + str(missing_versions[:10]))
        missing_attributes = [c.get("control_id") for c in self.controls_catalog
                              if not isinstance(c.get("attributes"), list)]
        self.check("CTRL-005", "Control attributes exposed", not missing_attributes,
                   "Records missing attribute list: " + str(missing_attributes[:10]))
        mapped = [c for c in self.controls_catalog if c.get("attributes")]
        if mapped:
            bad = [c.get("control_id") for c in mapped
                   if not all(nonempty(a.get("attribute_id") or a.get("question_id"))
                              for a in c["attributes"] if isinstance(a, dict))]
            self.check("CTRL-005", "Attributes have stable identifiers", not bad,
                       "Controls with missing attribute identifiers: " + str(bad[:10]))
        else:
            self.omitted("CTRL-005", "Attribute identifiers", "No attributes in control sample")
        self.check("DATA-005", "Authoritative control catalog accessible",
                   len(self.controls_catalog) > 0,
                   f"Fetched {len(self.controls_catalog)} control definitions (first page)")

    def questionnaire_checks(self):
        questionnaire = self.case.get("questionnaire")
        if not isinstance(questionnaire, dict):
            self.omitted("QUEST-001", "Questionnaire scope", "Questionnaire unavailable")
            return
        questions = questionnaire.get("questions") or []
        if not questions:
            self.omitted("QUEST-001", "Generated question-to-control relationship",
                         "Questionnaire has no generated questions at this stage")
        else:
            scoped = values_as_set(self.case.get("controls") or [])
            unresolved = [q.get("question_id") for q in questions if isinstance(q, dict)
                          and q.get("control_id") and q.get("control_id") not in scoped]
            no_ids = [i for i, q in enumerate(questions) if not isinstance(q, dict)
                      or not nonempty(q.get("question_id"))]
            self.check("QUEST-001", "Questions have IDs and scoped controls",
                       not unresolved and not no_ids,
                       f"Unscoped controls on questions: {unresolved[:10]}; missing IDs: {no_ids[:10]}")
        submitted = questionnaire.get("submitted_responses") or []
        if not submitted:
            self.omitted("QUEST-003", "Response provenance", "No submitted responses")
        else:
            missing = [r.get("question_id", str(i)) for i, r in enumerate(submitted)
                       if not isinstance(r, dict) or not nonempty(r.get("question_id"))
                       or not nonempty(r.get("answered_by")) or not nonempty(r.get("answered_at"))]
            self.check("QUEST-003", "Submitted response identity and timestamp", not missing,
                       "Responses missing provenance: " + str(missing[:10]))
        artifacts = self.case.get("artifacts") or []
        if not artifacts:
            self.omitted("QUEST-005", "Evidence metadata", "No stored artifacts to examine")
        else:
            missing = [a.get("artifact_id") or str(i) for i, a in enumerate(artifacts)
                       if not isinstance(a, dict) or not a.get("checksum") or not a.get("uploaded_at")]
            self.check("QUEST-005", "Stored artifacts have checksum and upload time",
                       not missing, "Artifacts missing metadata: " + str(missing[:10]))

    def validation_findings_checks(self):
        attrs = self.case.get("control_test_attributes") or []
        validated = [a for a in attrs if isinstance(a, dict) and nonempty(a.get("validation_status"))]
        if not validated:
            self.omitted("VALID-001", "Validation outcomes captured", "No validated control-test attributes")
        else:
            self.check("VALID-001", "Validation outcomes associated with attributes",
                       all(a.get("control_id") and a.get("question_id") for a in validated),
                       f"Examined {len(validated)} validated attributes")
        findings = self.case.get("findings") or []
        if not findings:
            self.omitted("FIND-001", "Finding-to-case traceability", "No case findings")
        else:
            missing = [f.get("id") or str(i) for i, f in enumerate(findings)
                       if not isinstance(f, dict) or not nonempty(f.get("id"))
                       or not (nonempty(f.get("question_id")) or nonempty(f.get("control_id")))]
            self.check("FIND-001", "Findings carry ID and control/question linkage", not missing,
                       "Findings missing linkage: " + str(missing[:10]))
            no_severity = [f.get("id") for f in findings if not nonempty(f.get("severity"))]
            self.check("FIND-003", "Findings have severity", not no_severity,
                       "Findings without severity: " + str(no_severity[:10]))
        reports = self.case.get("reports") or []
        if reports:
            self.check("REPORT-001", "Issued reports have version and snapshot",
                       all(isinstance(r, dict) and nonempty(r.get("version"))
                           and isinstance(r.get("snapshot"), dict) for r in reports),
                       f"Examined {len(reports)} issued report(s)")
        else:
            self.omitted("REPORT-001", "Issued report structures", "No issued reports")

    def check_api_docs(self):
        if not self.api:
            self.omitted("INTEG-006", "Machine-readable API documents",
                         "Offline mode; API service not queried")
            return
        for name in ("workflow-openapi.json", "library-openapi.json"):
            path = "/" + name
            status, data, error, duration = self.api.get(path)
            valid = status == 200 and isinstance(data, dict) and nonempty(data.get("openapi"))
            self.check("INTEG-006", "Published OpenAPI: " + name, valid,
                       "HTTP " + str(status) + ("; " + error if error else "")
                       + (f"; {duration} ms" if duration is not None else ""))

    def expected_behavior(self):
        expected = self.baseline.get("expected") or {}
        case = self.case
        options = (
            ("ASSESS-004", "Risk tier matches workbook baseline", "risk_tier",
             case.get("risk_tier")),
            ("INTAKE-002", "Assessment type matches intake baseline", "assessment_type",
             (case.get("intake") or {}).get("assessment_type")),
            ("ASSESS-006", "LIR qualification matches baseline", "lir_qualifies",
             ((case.get("low_impact_release") or {}).get("eligibility") or {}).get("qualifies")),
        )
        for rid, label, key, actual in options:
            if key in expected:
                self.check(rid, label, actual == expected[key],
                           f"expected={short(expected[key])}; actual={short(actual)}", "baseline")
        sets = (
            ("CTRL-003", "Scoped controls match expected set", "control_ids",
             values_as_set(case.get("controls") or [])),
            ("ASSET-004", "Asset types match expected set", "asset_types",
             values_as_set(case.get("assets") or [], "asset_type")),
            ("QUEST-001", "Generated question IDs match expected set", "question_ids",
             values_as_set((case.get("questionnaire") or {}).get("questions") or [], "question_id")),
            ("FIND-001", "Finding codes match expected set", "finding_codes",
             values_as_set(case.get("findings") or [], "code")),
        )
        for rid, label, key, actual in sets:
            if key in expected:
                wanted = set(str(x) for x in expected[key])
                self.check(rid, label, actual == wanted,
                           "missing=" + str(sorted(wanted - actual)) +
                           "; unexpected=" + str(sorted(actual - wanted)), "baseline")

        # Preserve repeated questions across different assets (asset-central model).
        if "question_pairs" in expected:
            actual = set()
            questions = (case.get("questionnaire") or {}).get("questions") or []
            for question in questions:
                if isinstance(question, dict) and question.get("question_id"):
                    actual.add((str(question.get("asset_id") or ""), str(question["question_id"])))
            wanted = set((str(item[0]), str(item[1])) for item in expected["question_pairs"])
            self.check("QUEST-001", "Asset/question pairs match workbook baseline",
                       actual == wanted, "missing=" + str(sorted(wanted - actual)) +
                       "; unexpected=" + str(sorted(actual - wanted)), "baseline")

        if "asset_control_map" in expected:
            actual = {}
            for asset in case.get("assets") or []:
                if isinstance(asset, dict) and asset.get("asset_id"):
                    actual[str(asset["asset_id"])] = set(str(x) for x in asset.get("control_ids") or [])
            wanted = {str(asset_id): set(str(x) for x in codes)
                      for asset_id, codes in expected["asset_control_map"].items()}
            self.check("CTRL-003", "Per-asset controls match workbook baseline",
                       actual == wanted, "expected=" + short({k: sorted(v) for k, v in wanted.items()}) +
                       "; actual=" + short({k: sorted(v) for k, v in actual.items()}), "baseline")

        if "gap_totals" in expected:
            actual = ((case.get("gap_analysis") or {}).get("results") or {})
            for key, wanted in expected["gap_totals"].items():
                self.check("VALID-001", "GAP result " + key + " matches baseline",
                           actual.get(key) == wanted,
                           f"{key}: expected={wanted}, actual={actual.get(key)}", "baseline")

        if "validation_outcomes" in expected:
            actual = {}
            for entry in case.get("control_test_attributes") or []:
                if isinstance(entry, dict) and entry.get("question_id"):
                    name = str(entry.get("asset_id") or "") + "|" + str(entry["question_id"])
                    actual[name] = entry.get("validation_status")
            for name, wanted in expected["validation_outcomes"].items():
                self.check("VALID-002", "Validation outcome " + name,
                           actual.get(name) == wanted,
                           f"expected={wanted}; actual={actual.get(name)}", "baseline")

        for i, condition in enumerate(self.baseline.get("assertions") or [], start=1):
            rid = condition.get("requirement")
            path = condition.get("path")
            if not rid or not path or rid not in {r["id"] for r in self.matrix}:
                self.problems.append(f"Skipping malformed baseline assertion {i}")
                continue
            found, actual = deep_value(case, path)
            operator = condition.get("operator", "equals")
            wanted = condition.get("expected")
            if operator == "equals":
                passed = found and actual == wanted
            elif operator == "not_empty":
                passed = found and nonempty(actual)
            elif operator == "contains":
                passed = found and isinstance(actual, (list, str, dict)) and wanted in actual
            else:
                self.problems.append(f"Unsupported assertion operator at {i}: {operator}")
                continue
            self.check(rid, condition.get("name", path), passed,
                       f"path={path}; expected={short(wanted)}; actual={short(actual)}",
                       "baseline")

    def run(self):
        if self.baseline and self.baseline.get("ritm") != self.ritm:
            self.problems.append("Baseline RITM must equal --ritm (refusing mismatched expectation)")
            return False
        if not self.fetch_case():
            return False
        self.fetch_catalogs()
        self.case_identity()
        self.intake_checks()
        self.assets_checks()
        self.control_checks()
        self.questionnaire_checks()
        self.validation_findings_checks()
        self.expected_behavior()
        self.check_api_docs()
        return True

    def coverage(self):
        """PARTIAL never means full SRS acceptance; tests use a limited sample."""
        coverage = []
        for requirement in self.matrix:
            tests = [x for x in self.tests if x["requirement"] == requirement["id"]]
            evaluated = [t for t in tests if t["result"] in ("PASS", "FAIL")]
            if any(t["result"] == "FAIL" for t in evaluated):
                status = "FAIL"
            elif evaluated:
                status = "PARTIAL"
            else:
                status = "NOT_TESTED"
            coverage.append({**requirement, "status": status,
                             "tests_run": len(evaluated), "tests_passed": sum(t["result"] == "PASS" for t in evaluated)})
        return coverage

    def reports(self, out_dir):
        out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)
        stamp = utc_stamp()
        coverage = self.coverage()
        totals = {v: sum(row["status"] == v for row in coverage)
                  for v in ("FAIL", "PARTIAL", "NOT_TESTED")}
        cases = {v: sum(row["result"] == v for row in self.tests)
                 for v in ("PASS", "FAIL", "NOT_TESTED")}
        data = {"generated_utc": now_utc(), "ritm": self.ritm,
                "srs": "CSCA-SRS-001 v1.0", "note": "PARTIAL is sample evidence, not full SRS compliance.",
                "requirement_summary": totals, "test_summary": cases, "issues": self.problems,
                "requirements": coverage, "tests": self.tests,
                "api_calls": self.api.calls if self.api else []}
        prefix = out / ("CSCA_SRS_" + self.ritm.replace("/", "_") + "_" + stamp)
        json_file = Path(str(prefix) + ".json")
        txt_file = Path(str(prefix) + ".txt")
        csv_file = Path(str(prefix) + "_traceability.csv")
        json_file.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")
        with csv_file.open("w", newline="", encoding="utf-8") as handle:
            fields = ["id", "priority", "title", "status", "tests_run", "tests_passed",
                      "api_support", "test_approach", "evidence_needed"]
            writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(coverage)
        lines = ["CSCA CENTRE — REQUIREMENTS-DRIVEN FUNCTIONAL TEST",
                 "=" * 103, "SRS: CSCA-SRS-001 v1.0", "RITM: " + self.ritm,
                 "Generated UTC: " + data["generated_utc"],
                 "Requirements: " + ", ".join(f"{k}={v}" for k, v in totals.items()),
                 "Assertions: " + ", ".join(f"{k}={v}" for k, v in cases.items()),
                 "PARTIAL = at least one passed assertion; full requirement acceptance NOT established.", "",
                 f"{'REQUIREMENT':<14}{'STATUS':<13}{'RUN':>5}  REQUIREMENT TITLE", "-" * 103]
        for row in coverage:
            lines.append(f"{row['id']:<14}{row['status']:<13}{row['tests_run']:>5}  {row['title']}")
        lines += ["", "EXECUTED ASSERTIONS", "-" * 103,
                  f"{'REQUIREMENT':<14}{'STATUS':<13}TEST", "-" * 103]
        for item in self.tests:
            lines.append(f"{item['requirement']:<14}{item['result']:<13}{item['test']}")
            if self.verbose or item["result"] == "FAIL":
                lines.append("    " + short(item["detail"], 220))
        if self.problems:
            lines += ["", "LIMITATIONS / ERRORS"]
            lines += ["- " + problem for problem in self.problems]
        txt_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return {"text": txt_file, "json": json_file, "csv": csv_file, "summary": totals,
                "assertions": cases}


def main(argv=None):
    p = argparse.ArgumentParser(description="Read-only CSCA requirements-driven API tests")
    p.add_argument("--ritm", required=True, help="Existing assessment RITM")
    p.add_argument("--base-url", default=os.getenv("CSCA_BASE_URL"),
                   help="URL ending in /libraries/v1 (or set CSCA_BASE_URL)")
    p.add_argument("--baseline", help="JSON expected outcomes for this RITM")
    p.add_argument("--case-file", help="Test a saved full-case JSON instead of calling the API")
    p.add_argument("--matrix", default=str(HERE / "srs_traceability.csv"))
    p.add_argument("--out-dir", default="csca_srs_results")
    p.add_argument("--ca-bundle", default=os.getenv("CSCA_CA_BUNDLE"),
                   help="Approved PEM CA bundle")
    p.add_argument("--insecure", action="store_true",
                   help="Disable server certificate validation, for temporary isolated testing only")
    p.add_argument("--timeout", type=int, default=30)
    p.add_argument("--verbose", action="store_true")
    args = p.parse_args(argv)
    if args.timeout <= 0:
        p.error("--timeout must be positive")
    if args.insecure and args.ca_bundle:
        p.error("Choose --insecure or --ca-bundle, not both")
    if args.ca_bundle and not Path(args.ca_bundle).is_file():
        p.error("No CA bundle at " + args.ca_bundle)
    try:
        matrix = load_matrix(args.matrix)
        baseline = json.loads(Path(args.baseline).read_text(encoding="utf-8-sig")) if args.baseline else {}
    except (OSError, ValueError) as exc:
        p.error("Cannot read traceability or baseline: " + str(exc))
    api = None
    if not args.case_file:
        if not args.base_url or not args.base_url.startswith("https://"):
            p.error("HTTPS --base-url is required unless --case-file is supplied")
        bearer = os.getenv("CSCA_BEARER_TOKEN")
        key = os.getenv("CSCA_LIBRARY_KEY")
        if not bearer and not key:
            p.error("Set CSCA_BEARER_TOKEN or CSCA_LIBRARY_KEY")
        if args.insecure:
            print("WARNING: TLS verification disabled; use only for a trusted, isolated test endpoint.",
                  file=sys.stderr)
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        api = Api(args.base_url, bearer or key, bool(bearer), args.ca_bundle,
                  args.insecure, args.timeout)
    test = SrsHarness(matrix, args.ritm, api, baseline, args.case_file, args.verbose)
    success = test.run()
    output = test.reports(args.out_dir)
    print("\nRequirement results:", output["summary"])
    print("Assertion results:", output["assertions"])
    for name in ("text", "json", "csv"):
        print(name.upper() + ":", output[name])
    if not success or output["summary"]["FAIL"] > 0:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
